# wt3_wsg_19ic_volume_v1.2

WT3 WSG 单通道 + 音量 里程碑 (v1.2)

## 概要
- 19 IC 全部显式实例化, 无隐藏芯片
- 单通道 8-bit 相位累加 + wavetable 查表 + 4-bit 音量
- 微码 32 step 循环 (8 有效 + 24 NOP), 3.072MHz STEP_CLK, 96kHz 采样率
- 钢琴式衰减包络演示 (CPU 软件包络, 1.5s 衰减)

## 芯片清单 (19 IC)
- 3 IC SPFM 总线: 373 + 174 + 377
- 3 IC 寄存器: 377 (reg_a phase_acc) + 377 (reg_b phase_step) + 377 (reg_c volume)
- 2 IC step 计数器: 161 ×2 (级联 5-bit)
- 2 IC ROM: 39SF040 (微码) + 39SF040 (wavetable 4KB)
- 5 IC 选择器: 157 ×5 (地址/DI/WE-OE 全显式)
- 1 IC RAM: CY62256 (32KB, 仅用 3B)
- 2 IC 加法器: 283 ×2 (8-bit 级联)
- 1 IC 输出: 273 (锁存 wavetable → DAC)

## 寄存器表 (CPU 接口)
| 地址 | 名称 | 说明 |
|------|------|------|
| 0x00 | phase_acc | 相位累加器 (硬件自动更新, CPU 一般不写) |
| 0x01 | phase_step | 频率参数 (CPU 写) |
| 0x02 | volume | 音量 (CPU 写, 低 4 位有效 0-15) |

频率公式: freq = phase_step × 96000 / 256 = phase_step × 375 Hz

## 编译运行
依赖: iverilog + vvp + Python 3

```bash
iverilog -o wt3_core.vvp -Wall \
    rtl/wt3_core.v rtl/wt3_spfm_bus.v \
    rtl/hc373.v rtl/hc174.v rtl/hc377.v rtl/hc273.v \
    rtl/hc157.v rtl/hc161.v rtl/hc283.v \
    rtl/hc39sf040.v rtl/hc62256.v \
    tb/wt3_core_tb.v

vvp wt3_core.vvp        # 满档振幅测试
python wt3_csv_to_wav.py wt3_sine.csv

# 钢琴包络演示
iverilog -o wt3_piano.vvp ... tb/wt3_piano_tb.v
vvp wt3_piano.vvp
python wt3_csv_to_wav.py wt3_piano.csv
```

## 演示音频
- wt3_sine.wav: 3kHz 满档正弦波 0.5s
- wt3_piano.wav: 3kHz 钢琴衰减 1.5s (vol=15→0)

## 文件清单
见 README 内本目录结构。

## 下一步
- v1.3: 6 通道扩展 (3.072MHz, 64kHz/通道, 8 step/通道, +0 IC)
- 加波形选择 (sine/square/saw/triangle, 复用 reg_c 高位, +0 IC)

---
生成时间: 2026-06-14T22:42:36
